import os
import sys
import subprocess
import ctypes

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def install():
    script_path = os.path.abspath("screenshot_service.pyw")
    python_exe = sys.executable.replace("python.exe", "pythonw.exe") # Use pythonw to hide console
    
    task_name = "UltraViewerScreenshotBot"
    
    # Command to create scheduled task
    # /sc onlogon : Trigger at user logon
    # /rl highest : Run with highest privileges (Admin)
    # /f : Force create/overwrite
    cmd = f'schtasks /create /tn "{task_name}" /tr "\'{python_exe}\' \'{script_path}\'" /sc onlogon /rl highest /f'
    
    print(f"Executing: {cmd}")
    try:
        subprocess.check_call(cmd, shell=True)
        print(f"\n[SUCCESS] Task '{task_name}' successfully created!")
        print("Scipt will now run automatically when you login.")
        print("Please restart your computer or sign out/sign in to test persistence.")
        
        # Ask to run immediately
        print("\nStarting service now for testing...")
        subprocess.Popen([python_exe, script_path])
        print("Service started.")
        
    except subprocess.CalledProcessError as e:
        print(f"\n[ERROR] Failed to create task. Error code: {e.returncode}")

if __name__ == "__main__":
    if is_admin():
        install()
        input("\nPress Enter to exit...")
    else:
        # Re-run the program with admin rights
        print("Requesting Administrator privileges...")
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
