@echo off
title UltraViewer Bot Installer

:: 1. Auto-Elevate to Administrator
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [INFO] Requesting Administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: 2. Set Working Directory to Script Location
cd /d "%~dp0"

echo ==========================================
echo      INSTALLING ULTRAVIEWER BOT
echo ==========================================
echo.

echo [Step 1] Installing Python Libraries...
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install requirements. Please check Python installation.
    pause
    exit /b
)
echo [OK] Libraries installed.
echo.

echo [Step 2] Registering Startup System...
:: Run install.py. It will detect Admin rights (inherited) and do the work.
python install.py

:: Note: install.py has its own "Press Enter to exit", so the window will stay open.
echo.
echo ==========================================
echo               DONE!
echo ==========================================
