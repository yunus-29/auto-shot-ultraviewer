import telebot
import mss
import mss.tools
import psutil
import time
import socket
import sys
import subprocess
import os
import ctypes
import threading
import io
import win32gui
import win32con
import win32process
import win32api
import win32com.client
from PIL import Image
from ctypes import windll, Structure, c_uint, sizeof, byref
import datetime
import traceback

# --- DEBUG LOGGING ---
LOG_FILE = r"d:\Auto shot window\debug_bot.log"
def log(msg):
    try:
        with open(LOG_FILE, "a") as f:
            f.write(f"[{datetime.datetime.now()}] {msg}\n")
    except:
        pass

log("Script Starting...")
try:
    log(f"Hostname: {socket.gethostname()}")
except Exception as e:
    log(f"Init Error: {e}")

# --- CONFIGURATION ---
BOT_TOKEN = "8389092765:AAFcNOM9OP3WxKZQF1IyUfvq_lBxs12ICgg"
ULTRAVIEWER_PATH = r"C:\Program Files (x86)\UltraViewer\UltraViewer_Desktop.exe"
PROCESS_NAME = "UltraViewer_Desktop.exe"
IDLE_THRESHOLD = 5  # Seconds
WINDOW_TITLE_KEYWORD = "UltraViewer"

# --- SYSTEM HELPERS ---
class LASTINPUTINFO(Structure):
    _fields_ = [
        ('cbSize', c_uint),
        ('dwTime', c_uint),
    ]

def force_bring_to_front(hwnd):
    """Forces a window to the foreground using SwitchToThisWindow and Alt key."""
    try:
        # 1. Bruteforce with SwitchToThisWindow (Legacy API)
        # un-minimize if minimized
        if win32gui.IsIconic(hwnd):
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
        else:
            win32gui.ShowWindow(hwnd, win32con.SW_SHOW)
            
        # Magic function to bring to front
        windll.user32.SwitchToThisWindow(hwnd, True)

        # 2. FORCE TOPMOST (The only way to guarantee visibility over other windows)
        win32gui.SetWindowPos(hwnd, win32con.HWND_TOPMOST, 0, 0, 0, 0, 
                              win32con.SWP_NOMOVE | win32con.SWP_NOSIZE | win32con.SWP_SHOWWINDOW)
        
        # 3. Standard SetForeground
        win32gui.SetForegroundWindow(hwnd)
        return True
    except Exception as e:
        print(f"Focus Error: {e}")
        return False

def get_idle_duration():
    """Returns the number of seconds since the last user input."""
    lastInputInfo = LASTINPUTINFO()
    lastInputInfo.cbSize = sizeof(lastInputInfo)
    windll.user32.GetLastInputInfo(byref(lastInputInfo))
    millis = windll.kernel32.GetTickCount() - lastInputInfo.dwTime
    return millis / 1000.0

def get_hostname():
    return socket.gethostname()

def is_process_running(process_name):
    for proc in psutil.process_iter(['name']):
        try:
            if process_name.lower() in proc.info['name'].lower():
                return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return False

def start_ultraviewer():
    if not os.path.exists(ULTRAVIEWER_PATH):
        return False, "Path UltraViewer salah/tidak ditemukan."
    
    if is_process_running(PROCESS_NAME):
        return True, "Already running."
    
    try:
        subprocess.Popen(ULTRAVIEWER_PATH)
        time.sleep(10) # Wait for startup
        return True, "Started."
    except Exception as e:
        return False, str(e)

def find_window_handle(keyword):
    """Find window handle by title keyword, ignoring 0-size ghost windows."""
    valid_hwnds = []
    
    def callback(hwnd, ctx):
        text = win32gui.GetWindowText(hwnd)
        if keyword.lower() in text.lower():
            # Check size
            try:
                rect = win32gui.GetWindowRect(hwnd)
                width = rect[2] - rect[0]
                height = rect[3] - rect[1]
                # Filter out tiny/invisible utility windows
                if width > 10 and height > 10:
                    valid_hwnds.append(hwnd)
            except:
                pass
    
    win32gui.EnumWindows(callback, None)
    
    # Prioritize Visible Windows
    for hwnd in valid_hwnds:
        if win32gui.IsWindowVisible(hwnd):
            return hwnd
            
    # If no visible found, return the first valid hidden (minimized) one
    if valid_hwnds:
        return valid_hwnds[0]
        
    return None

# --- BOT SETUP ---
bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    hostname = get_hostname()
    help_text = (
        f"🤖 UltraViewer Bot on {hostname}\n\n"
        "Available Commands:\n"
        "`/ss [name]` - Screenshot. Bisa spesifik nama laptop.\n"
        "`/restore [name]` - Matikan paksa & nyalakan ulang Ultraviewer.\n"
        "`/help` - Tampilkan pesan ini.\n\n"
        "Notes:\n"
        "- Bot akan menolak ss jika laptop sedang dipakai (user ngetik/mouse gerak).\n"
        "- Gambar akan menampilkan nama aplikasi yang sedang aktif jika dibatalkan."
    )
    bot.reply_to(message, help_text)

@bot.message_handler(content_types=['document'])
def handle_file_update(message):
    hostname = get_hostname()
    
    # Check Caption for /update command
    if not message.caption or not message.caption.startswith('/update'):
        return

    # Check Target
    args = message.caption.split()
    if len(args) > 1:
        target = args[1].lower()
        if target not in hostname.lower():
            return

    try:
        file_info = bot.get_file(message.document.file_id)
        downloaded_file = bot.download_file(file_info.file_path)
        
        # Save to current script path
        current_script = os.path.abspath(__file__)
        with open(current_script, 'wb') as new_file:
            new_file.write(downloaded_file)
            
        bot.reply_to(message, f"✅ Update Success on {hostname}. Restarting...")
        
        # Self-Restart
        time.sleep(1)
        os.execv(sys.executable, [sys.executable] + sys.argv)
        
    except Exception as e:
        bot.reply_to(message, f"❌ Update Failed on {hostname}: {e}")

@bot.message_handler(commands=['restore', 'restart', 'fix'])
def handle_restore(message):
    hostname = get_hostname()
    
    # Check Arguments (Target Filtering)
    args = message.text.split()
    if len(args) > 1:
        target = args[1].lower()
        if target not in hostname.lower():
            return

    bot.reply_to(message, f"🛠️ Restoring UltraViewer on {hostname}...\nMematikan proses lama...")
    
    # 1. Kill Process
    killed = False
    for proc in psutil.process_iter(['name']):
        try:
            if PROCESS_NAME.lower() in proc.info['name'].lower():
                proc.kill()
                killed = True
        except:
            pass
    
    time.sleep(2) # Give time to die
    
    # 2. Start Process
    bot.send_message(message.chat.id, f"🔄 Starting UltraViewer on {hostname}...")
    success, msg = start_ultraviewer()
    
    if success:
         bot.reply_to(message, f"✅ UltraViewer Restored on {hostname}.")
    else:
         bot.reply_to(message, f"❌ Gagal start ulang pada {hostname}: {msg}")


@bot.message_handler(commands=['ss', 'capture'])
def handle_screenshot(message):
    log(f"Cmd /ss received from {message.chat.id}")
    hostname = get_hostname()
    chat_id = message.chat.id
    
    # 0. Check Arguments (Target Filtering)
    # Format: /ss [optional_target_hostname]
    args = message.text.split()
    if len(args) > 1:
        target = args[1].lower()
        # If target is provided, but doesn't match this hostname, IGNORE.
        if target not in hostname.lower():
            return
    
    # 1. Check Idle
    idle_time = get_idle_duration()
    if idle_time < IDLE_THRESHOLD:
        # Get Active Window Title for Log
        try:
             active_window = win32gui.GetForegroundWindow()
             active_title = win32gui.GetWindowText(active_window)
        except:
             active_title = "Unknown"

        bot.reply_to(message, f"⛔ Action Aborted on {hostname}\n"
                              f"Laptop sedang digunakan (Active {int(idle_time)}s ago).\n"
                              f"👤 Current Activity: `{active_title}`")
        return

    # 2. Check & Start Process
    if not is_process_running(PROCESS_NAME):
        bot.send_message(chat_id, f"🔄 Starting UltraViewer on {hostname}...")
        success, msg = start_ultraviewer()
        if not success:
            bot.reply_to(message, f"❌ Failed to start UltraViewer on {hostname}: {msg}")
            return
    
    # 3. Handling Window & Capture
    hwnd = find_window_handle(WINDOW_TITLE_KEYWORD)
    
    if not hwnd:
        bot.reply_to(message, f"⚠️ Process Running but Window Not Found on {hostname}.\nMungkin minimize ke Tray (bukan Taskbar).")
        return

    # Check if window needs to be restored from Tray/Minimize
    is_tray = not win32gui.IsWindowVisible(hwnd)
    is_minimized = win32gui.IsIconic(hwnd)
    should_hide_after = is_tray or is_minimized
    
    try:
        # Prevent race conditions with basic lock if needed, but single threaded bot is fine usually
        # FORCE FOCUS
        try:
             force_bring_to_front(hwnd)
             time.sleep(0.8) # Wait for render
        except Exception as err:
             bot.reply_to(message, f"⚠️ Warning on {hostname}: Gagal SetForegroundWindow.\nErr: `{err}`")

        # CAPTURE
        with mss.mss() as sct:
            rect = win32gui.GetWindowRect(hwnd)
            monitor = {"top": rect[1], "left": rect[0], "width": rect[2]-rect[0], "height": rect[3]-rect[1]}
            
            # Validasi ukuran
            # Validasi ukuran
            if monitor["width"] <= 0 or monitor["height"] <= 0:
                 bot.reply_to(message, f"❌ Window size invalid on {hostname}.")
                 if should_hide_after: win32gui.ShowWindow(hwnd, win32con.SW_MINIMIZE)
                 return

            sct_img = sct.grab(monitor)
            
            # Convert using Pillow (More fast & robust)
            img = Image.frombytes("RGB", sct_img.size, sct_img.rgb)
            
            # Save to Memory
            img_bytes = io.BytesIO()
            img.save(img_bytes, format='PNG')
            img_bytes.seek(0)
            img_bytes.name = f"screenshot_{hostname}.png" # Helps telegram detect type
            
            # Send
            log(f"Sending screenshot from {hostname}")
            bot.send_photo(chat_id, img_bytes, caption=f"📸 Screenshot from: `{hostname}`")
            log("Sent successfully.")

    except Exception as e:
        bot.reply_to(message, f"❌ Error capturing on {hostname}: {e}")
    finally:
        # Restore state
        try:
             # Unset TopMost so it doesn't float forever
             win32gui.SetWindowPos(hwnd, win32con.HWND_NOTOPMOST, 0, 0, 0, 0, win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
        except:
             pass

        if should_hide_after:
            win32gui.ShowWindow(hwnd, win32con.SW_MINIMIZE)

log(f"Bot Started on {get_hostname()}...")

# Infinite Retry Loop (Resilient to Network Failures)
while True:
    try:
        log("Connecting to Telegram...")
        # timeout=20 ensures it sends keep-alive packages
        # long_polling_timeout=20 keeps connection open
        bot.infinity_polling(timeout=20, long_polling_timeout=20)
    except Exception as e:
        log(f"Bot Connection Error: {e}")
        time.sleep(15)  # Wait before retrying connection
